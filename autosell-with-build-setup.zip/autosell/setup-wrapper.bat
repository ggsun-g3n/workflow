@echo off
REM =============================================================
REM AutoSell Mod - Gradle Wrapper Setup (Windows)
REM Run this ONCE to download gradle-wrapper.jar
REM =============================================================

set JAR_PATH=gradle\wrapper\gradle-wrapper.jar
set JAR_URL=https://github.com/gradle/gradle/raw/v7.3.3/gradle/wrapper/gradle-wrapper.jar

echo ============================================
echo   AutoSell Mod - Gradle Wrapper Setup
echo ============================================

if exist "%JAR_PATH%" (
    echo [OK] gradle-wrapper.jar already exists. Skipping.
    exit /b 0
)

echo [*] Downloading gradle-wrapper.jar...

powershell -Command "Invoke-WebRequest -Uri '%JAR_URL%' -OutFile '%JAR_PATH%'" 2>nul
if errorlevel 1 (
    echo [ERR] Download failed.
    echo       Manually download from:
    echo       %JAR_URL%
    echo       Aur yahan rakh do: %JAR_PATH%
    pause
    exit /b 1
)

if exist "%JAR_PATH%" (
    echo [OK] gradle-wrapper.jar download ho gaya!
    echo.
    echo Ab build karo:
    echo   gradlew.bat build
    echo.
    echo Compiled .jar milega: build\libs\autosell-1.0.0.jar
) else (
    echo [ERR] Download fail ho gaya.
)

pause
