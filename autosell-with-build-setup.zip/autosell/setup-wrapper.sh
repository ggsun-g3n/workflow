#!/bin/bash
# =============================================================
# AutoSell Mod - Gradle Wrapper Setup Script
# Run this ONCE to download gradle-wrapper.jar
# After this, use ./gradlew build for everything
# =============================================================

JAR_URL="https://github.com/gradle/gradle/raw/v7.3.3/gradle/wrapper/gradle-wrapper.jar"
JAR_PATH="gradle/wrapper/gradle-wrapper.jar"

echo "============================================"
echo "  AutoSell Mod - Gradle Wrapper Setup"
echo "============================================"

if [ -f "$JAR_PATH" ]; then
    echo "✅ gradle-wrapper.jar already exists. Skipping."
    exit 0
fi

echo "📥 Downloading gradle-wrapper.jar..."

# Try curl first, then wget
if command -v curl &> /dev/null; then
    curl -L -o "$JAR_PATH" "$JAR_URL"
elif command -v wget &> /dev/null; then
    wget -O "$JAR_PATH" "$JAR_URL"
else
    echo "❌ Error: curl ya wget koi bhi nahi mila."
    echo "   Manually download karo:"
    echo "   $JAR_URL"
    echo "   Aur yahan rakh do: $JAR_PATH"
    exit 1
fi

if [ -f "$JAR_PATH" ]; then
    echo "✅ gradle-wrapper.jar download ho gaya!"
    chmod +x gradlew
    echo ""
    echo "Ab build karo:"
    echo "  ./gradlew build"
    echo ""
    echo "Compiled .jar milega:  build/libs/autosell-1.0.0.jar"
else
    echo "❌ Download fail ho gaya."
fi
