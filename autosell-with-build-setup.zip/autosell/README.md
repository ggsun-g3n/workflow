# AutoSell — Fabric Mod for Minecraft 1.17.1

Auto-sells selected inventory items using a configurable server sell command.

**Author:** Ggsun  
**MC Version:** 1.17.1  
**Loader:** Fabric

---

## ⚡ Build Karne Ke 3 Tarike (koi compromise nahi)

### 🥇 Option 1 — GitHub Actions (Sabse Aasaan, Kuch Install Nahi Karna)

> Push karo, compiled `.jar` GitHub pe download milega. Java bhi install nahi chahiye.

1. GitHub pe ek naya repo banao
2. Saara code push karo
3. **Actions tab** kholo → "Build AutoSell Mod" → Run
4. Build complete hone ke baad **Artifacts** section mein `.jar` milega ✅

**Auto-release bhi hota hai:**
```bash
git tag v1.0.0
git push origin v1.0.0
# GitHub Releases mein automatically .jar attach ho jaata hai
```

---

### 🥈 Option 2 — Local Build (Gradlew ke saath)

**Requirements:** Java 16 JDK  
**Gradle manually install karne ki zaroorat NAHI**

```bash
# Step 1: Pehli baar sirf yeh run karo (wrapper.jar download karta hai)
bash setup-wrapper.sh        # Linux/Mac
setup-wrapper.bat            # Windows

# Step 2: Build!
./gradlew build              # Linux/Mac
gradlew.bat build            # Windows

# .jar milega:
build/libs/autosell-1.0.0.jar
```

---

### 🥉 Option 3 — VS Code Dev Container (Ek Click Setup)

> Java install nahi, Gradle install nahi, kuch bhi nahi. VS Code + Docker chahiye.

1. VS Code mein folder kholo
2. Popup aaye **"Reopen in Container"** → click karo
3. Container ready hone ke baad terminal mein:
   ```bash
   ./gradlew build
   ```

---

## 📁 Project Structure

```
autosell/
├── .github/workflows/
│   ├── build.yml          ← Push pe auto-build
│   └── release.yml        ← Tag pe auto-release
├── .devcontainer/
│   └── devcontainer.json  ← VS Code container config
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── src/main/java/com/ggsun/autosell/
│   ├── AutoSellMod.java
│   ├── AutoSellManager.java
│   ├── AutoSellConfig.java
│   ├── SellRecord.java
│   └── gui/AutoSellScreen.java
├── build.gradle
├── gradle.properties
├── gradlew / gradlew.bat
└── setup-wrapper.sh / .bat   ← Pehli baar chalao
```

---

## 🔧 Common Commands

```bash
./gradlew build          # Full build + .jar
./gradlew clean          # Build folder saaf karo
./gradlew clean build    # Fresh build
./gradlew --stop         # Gradle daemon band karo
```

---

## ⚠️ Note

`gradle/wrapper/gradle-wrapper.jar` is a binary file.  
Pehli baar `setup-wrapper.sh` (ya `.bat`) run karo — yeh automatic download kar lega.  
GitHub Actions pe yeh problem nahi, wahan sab kuch auto-handle hota hai.
