package com.ggsun.autosell.gui;

import com.ggsun.autosell.AutoSellConfig;
import com.ggsun.autosell.AutoSellMod;
import com.ggsun.autosell.SellRecord;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class AutoSellScreen extends Screen {

    private static final int FIELD_W = 240;
    private static final int LIST_W  = 240;
    private static final int ITEM_H  = 20;
    private static final int HIST_W  = 150;
    private static final DateTimeFormatter TIME_FMT =
            DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault());

    /** Pre-computed per-item data so nothing is looked up or allocated per frame. */
    private static final class Entry {
        final ItemStack stack;
        final String id;     // minecraft:diamond
        final String path;   // diamond
        final String name;   // Diamond
        final String lower;  // diamond (lower-case display name)

        Entry(Item item) {
            Identifier ident = Registry.ITEM.getId(item);
            this.stack = new ItemStack(item);
            this.id = ident.toString();
            this.path = ident.getPath();
            this.name = stack.getName().getString();
            this.lower = name.toLowerCase(Locale.ROOT);
        }
    }

    // Built when the screen opens, released when it closes (saves memory).
    private static List<Entry> ALL;

    private final Screen parent;

    private TextFieldWidget commandField;
    private TextFieldWidget searchField;

    private final List<Entry> filtered = new ArrayList<>();
    private String selectedItem = "";
    private Entry selectedEntry;
    private int firstRow = 0;
    private int visibleRows = 5;
    private int listX, listY, left;
    private boolean histFits;
    private int histX;

    // Cached history text
    private final List<String> histLabels = new ArrayList<>();
    private final List<String> histQtys = new ArrayList<>();
    private int histSig = Integer.MIN_VALUE;
    private String lastSoldLine = "";

    public AutoSellScreen(Screen parent) {
        super(new LiteralText("AutoSell Config"));
        this.parent = parent;
    }

    private static List<Entry> allItems() {
        if (ALL == null) {
            List<Entry> list = new ArrayList<>(Registry.ITEM.getIds().size());
            for (Item item : Registry.ITEM) {
                if (item == Items.AIR) continue;
                list.add(new Entry(item));
            }
            list.sort(Comparator.comparing(e -> e.lower));
            ALL = list;
        }
        return ALL;
    }

    @Override
    protected void init() {
        super.init();
        AutoSellConfig cfg = AutoSellMod.config;
        selectedItem = cfg.selectedItem != null ? cfg.selectedItem : "";

        int totalW = FIELD_W + 22 + 10 + HIST_W;
        histFits = width >= totalW + 20;
        left = histFits ? (width - totalW) / 2 : width / 2 - FIELD_W / 2;
        histX = left + FIELD_W + 32;
        listX = left;

        commandField = new TextFieldWidget(textRenderer, left, 32, FIELD_W, 16,
                new LiteralText("sell command"));
        commandField.setMaxLength(128);
        commandField.setText(cfg.sellCommand != null ? cfg.sellCommand : "");
        commandField.setSuggestion(commandField.getText().isEmpty() ? "/sell {item}" : "");
        commandField.setChangedListener(t ->
                commandField.setSuggestion(t.isEmpty() ? "/sell {item}" : ""));
        addSelectableChild(commandField);

        listY = 108;
        searchField = new TextFieldWidget(textRenderer, left, 90, FIELD_W, 14,
                new LiteralText("search"));
        searchField.setMaxLength(64);
        searchField.setChangedListener(t -> { refilter(); firstRow = 0; });
        addSelectableChild(searchField);

        int btnY = height - 24;
        visibleRows = Math.max(3, (height - 44 - listY) / ITEM_H);

        int sbH = Math.max(10, (visibleRows * ITEM_H) / 2 - 1);
        addDrawableChild(new ButtonWidget(left + LIST_W + 3, listY, 16, sbH,
                new LiteralText("▲"), b -> scrollRows(-visibleRows)));
        addDrawableChild(new ButtonWidget(left + LIST_W + 3, listY + visibleRows * ITEM_H - sbH, 16, sbH,
                new LiteralText("▼"), b -> scrollRows(visibleRows)));

        addDrawableChild(new ButtonWidget(left, btnY, 116, 18, toggleLabel(),
                b -> {
                    AutoSellMod.config.enabled = !AutoSellMod.config.enabled;
                    b.setMessage(toggleLabel());
                    AutoSellMod.config.save();
                }));

        addDrawableChild(new ButtonWidget(left + FIELD_W - 116, btnY, 116, 18,
                new LiteralText("Save & Close"), b -> saveAndClose()));

        refilter();
        selectedEntry = null;
        for (int i = 0; i < filtered.size(); i++) {
            Entry e = filtered.get(i);
            if (e.id.equals(selectedItem)) {
                selectedEntry = e;
                firstRow = Math.max(0, i - visibleRows / 2);
                break;
            }
        }
        clampScroll();
        refreshHistory(true);
        setInitialFocus(commandField);
    }

    private LiteralText toggleLabel() {
        return new LiteralText(AutoSellMod.config.enabled
                ? "Auto-sell: §aON" : "Auto-sell: §cOFF");
    }

    private void refilter() {
        filtered.clear();
        String q = searchField == null ? "" : searchField.getText().trim().toLowerCase(Locale.ROOT);
        String qPath = q.replace(' ', '_');
        for (Entry e : allItems()) {
            if (q.isEmpty() || e.lower.contains(q) || e.path.contains(qPath)) {
                filtered.add(e);
            }
        }
        clampScroll();
    }

    private void scrollRows(int delta) {
        firstRow += delta;
        clampScroll();
    }

    private void clampScroll() {
        int max = Math.max(0, filtered.size() - visibleRows);
        firstRow = Math.max(0, Math.min(firstRow, max));
    }

    private void saveAndClose() {
        AutoSellMod.config.sellCommand = commandField.getText().trim();
        AutoSellMod.config.selectedItem = selectedItem;
        AutoSellMod.config.save();
        client.setScreen(parent);
    }

    /** Rebuilds the history strings only when the history actually changed. */
    private void refreshHistory(boolean force) {
        List<SellRecord> hist = AutoSellMod.config.history;
        int sig = hist.isEmpty() ? 0 : hist.size() * 31 + (int) hist.get(0).time;
        if (!force && sig == histSig) return;
        histSig = sig;
        histLabels.clear();
        histQtys.clear();
        lastSoldLine = hist.isEmpty() ? "§8Last sold: none"
                : "§7Last sold: §f" + hist.get(0).item + " x" + hist.get(0).qty;
        for (int i = 0; i < Math.min(10, hist.size()); i++) {
            SellRecord r = hist.get(i);
            String qty = " §ax" + r.qty;
            histQtys.add(qty);
            histLabels.add(textRenderer.trimToWidth(
                    "§8" + TIME_FMT.format(Instant.ofEpochMilli(r.time)) + " §f" + r.item,
                    HIST_W - 8 - textRenderer.getWidth(qty)));
        }
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        fillGradient(matrices, 0, 0, width, height, 0xC5101010, 0xD0101010);

        int cx = left + FIELD_W / 2;
        drawCenteredText(matrices, textRenderer, new LiteralText("§eAutoSell Config"), width / 2, 10, 0xFFFFFF);

        drawTextWithShadow(matrices, textRenderer, new LiteralText("§7Sell Command:"), left, 21, 0xFFFFFF);
        commandField.render(matrices, mouseX, mouseY, delta);
        drawTextWithShadow(matrices, textRenderer,
                new LiteralText("§8Sent as typed. {item} = selected item. Qty = 1"), left, 51, 0xFFFFFF);

        if (commandField.getText().isBlank()) {
            drawTextWithShadow(matrices, textRenderer,
                    new LiteralText("§c! Please enter the sell command, otherwise the system won't work."),
                    left, 62, 0xFFFFFF);
        }

        drawTextWithShadow(matrices, textRenderer,
                new LiteralText("§7Select item to auto-sell (" + filtered.size() + " items):"),
                left, 77, 0xFFFFFF);
        searchField.render(matrices, mouseX, mouseY, delta);
        if (searchField.getText().isEmpty() && !searchField.isFocused()) {
            drawTextWithShadow(matrices, textRenderer, new LiteralText("§8Search item..."),
                    left + 4, 93, 0xFFFFFF);
        }

        int listH = visibleRows * ITEM_H;
        fill(matrices, listX - 1, listY - 1, listX + LIST_W + 1, listY + listH + 1, 0x88000000);

        for (int r = 0; r < visibleRows; r++) {
            int idx = firstRow + r;
            if (idx >= filtered.size()) break;
            Entry e = filtered.get(idx);
            int rowY = listY + r * ITEM_H;
            boolean sel = e.id.equals(selectedItem);
            boolean hover = mouseX >= listX && mouseX < listX + LIST_W
                    && mouseY >= rowY && mouseY < rowY + ITEM_H;

            if (sel) fill(matrices, listX, rowY, listX + LIST_W, rowY + ITEM_H, 0x88005500);
            else if (hover) fill(matrices, listX, rowY, listX + LIST_W, rowY + ITEM_H, 0x44FFFFFF);

            client.getItemRenderer().renderGuiItemIcon(e.stack, listX + 3, rowY + 2);
            textRenderer.drawWithShadow(matrices, e.name, listX + 24, rowY + (ITEM_H - 8) / 2,
                    sel ? 0x55FF55 : 0xFFFFFF);
        }

        if (filtered.isEmpty()) {
            drawCenteredText(matrices, textRenderer, new LiteralText("§7No items found"),
                    cx, listY + listH / 2 - 4, 0xFFFFFF);
        }

        int selY = height - 38;
        if (selectedEntry != null) {
            client.getItemRenderer().renderGuiItemIcon(selectedEntry.stack, left, selY - 4);
            textRenderer.drawWithShadow(matrices, "§7Selected: §f" + selectedEntry.name,
                    left + 20, selY, 0xFFFFFF);
        } else {
            textRenderer.drawWithShadow(matrices, "§7No item selected - click one above",
                    left, selY, 0xFFFFFF);
        }

        renderHistory(matrices);
        super.render(matrices, mouseX, mouseY, delta);
    }

    private void renderHistory(MatrixStack matrices) {
        refreshHistory(false);

        if (!histFits) {
            textRenderer.drawWithShadow(matrices, lastSoldLine, left, height - 50, 0xFFFFFF);
            return;
        }

        int hy = 32, rowH = 11, boxH = 10 * rowH + 4;
        textRenderer.drawWithShadow(matrices, "§7Recent sells (last 10)", histX, 21, 0xFFFFFF);
        fill(matrices, histX - 1, hy - 1, histX + HIST_W + 1, hy + boxH + 1, 0x88000000);

        if (histLabels.isEmpty()) {
            textRenderer.drawWithShadow(matrices, "§8No sells yet", histX + 4, hy + 4, 0xFFFFFF);
            return;
        }
        for (int i = 0; i < histLabels.size(); i++) {
            int y = hy + 3 + i * rowH;
            String qty = histQtys.get(i);
            textRenderer.drawWithShadow(matrices, histLabels.get(i), histX + 4, y, 0xFFFFFF);
            textRenderer.drawWithShadow(matrices, qty,
                    histX + HIST_W - 4 - textRenderer.getWidth(qty), y, 0xFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (mouseX >= listX && mouseX < listX + LIST_W
                && mouseY >= listY && mouseY < listY + visibleRows * ITEM_H) {
            int idx = firstRow + (int) ((mouseY - listY) / ITEM_H);
            if (idx >= 0 && idx < filtered.size()) {
                Entry e = filtered.get(idx);
                if (e.id.equals(selectedItem)) {
                    selectedItem = "";
                    selectedEntry = null;
                } else {
                    selectedItem = e.id;
                    selectedEntry = e;
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (mouseX >= listX && mouseX < listX + LIST_W + 20
                && mouseY >= listY && mouseY < listY + visibleRows * ITEM_H) {
            scrollRows((int) -Math.signum(amount) * 2);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) { // Enter
            saveAndClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        super.removed();
        ALL = null; // free the item cache while the screen is closed
    }

    @Override
    public void onClose() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
