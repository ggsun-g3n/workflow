package com.ggsun.autosell.mixin;

import com.ggsun.autosell.AutoSellManager;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {

    // require = 0: if this hook can't be applied on some version, the game still
    // starts normally (only the "hide replies" feature is lost).
    @Inject(method = "onGameMessage", at = @At("HEAD"), cancellable = true, require = 0)
    private void autosell$hideSellReply(GameMessageS2CPacket packet, CallbackInfo ci) {
        if (AutoSellManager.isSuppressing()) {
            ci.cancel();
        }
    }
}
