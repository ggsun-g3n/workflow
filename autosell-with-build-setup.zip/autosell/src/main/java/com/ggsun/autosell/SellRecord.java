package com.ggsun.autosell;

public class SellRecord {
    public String item = "";
    public int qty = 1;
    public long time = 0L;

    public SellRecord() {}

    public SellRecord(String item, int qty, long time) {
        this.item = item;
        this.qty = qty;
        this.time = time;
    }
}
