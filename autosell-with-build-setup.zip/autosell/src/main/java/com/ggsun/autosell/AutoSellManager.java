package com.ggsun.autosell;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class AutoSellManager {

    private static final long SUPPRESS_MS = 1500;
    private static final int CHECK_DELAY_TICKS = 15;
    private static final int FLUSH_TICKS = 1200; // write history to disk at most once a minute

    private static volatile long suppressUntil = 0L;

    private int ticksSinceSell = 0;
    private int flushTicks = 0;
    private int now = 0;

    private boolean pending = false;
    private int countBefore = 0;
    private int checkAt = 0;

    // Resolved once per selected item (no string parsing every tick)
    private String cachedKey = "";
    private Item cachedItem = Items.AIR;
    private String cachedPath = "";
    private String cachedName = "";

    public static boolean isSuppressing() {
        return suppressUntil != 0L && System.currentTimeMillis() < suppressUntil;
    }

    public void onTick(MinecraftClient client) {
        AutoSellConfig cfg = AutoSellMod.config;
        if (cfg == null) return;
        try {
            tick(client, cfg);
        } catch (Exception e) {
            // Never crash the game: switch auto-sell off and tell the user
            cfg.enabled = false;
            pending = false;
            try {
                if (client.inGameHud != null) {
                    client.inGameHud.setOverlayMessage(
                            new LiteralText("§cAutoSell stopped (error). Turn it on again."), false);
                }
            } catch (Exception ignored) { }
        }
    }

    private void tick(MinecraftClient client, AutoSellConfig cfg) {
        if (++flushTicks >= FLUSH_TICKS) {
            flushTicks = 0;
            cfg.saveIfDirty();
        }

        // Idle path: costs almost nothing when switched off or not in a world
        if (!cfg.enabled || client.player == null || client.world == null) {
            pending = false;
            return;
        }

        now++;

        if (pending) {
            if (now < checkAt) return;
            pending = false;
            evaluate(client, cfg);
        }

        if (client.currentScreen != null) return;
        if (cfg.sellCommand.isEmpty() || cfg.selectedItem.isEmpty()) return;

        if (++ticksSinceSell < cfg.sellIntervalTicks) return;
        ticksSinceSell = 0;

        if (!resolve(cfg.selectedItem)) return;

        int have = countItem(client);
        if (have < 1) return;

        String cmd = cfg.sellCommand.trim();
        if (cmd.isEmpty()) return;
        if (cmd.charAt(0) != '/') cmd = "/" + cmd;
        if (cmd.indexOf('{') >= 0 || cmd.indexOf('[') >= 0) {
            cmd = cmd.replace("{item}", cachedPath)
                     .replace("[item_name]", cachedPath)
                     .replace("{qty}", "1")
                     .replace("[qty]", "1")
                     .replace("[quantity]", "1");
        }

        pending = true;
        countBefore = have;
        checkAt = now + CHECK_DELAY_TICKS;
        if (cfg.hideServerMessages) {
            suppressUntil = System.currentTimeMillis() + SUPPRESS_MS;
        }
        client.player.sendChatMessage(cmd);
    }

    private void evaluate(MinecraftClient client, AutoSellConfig cfg) {
        int after = countItem(client);
        if (after < countBefore) {
            cfg.addHistory(cachedName, countBefore - after); // memory only, no disk write
        } else {
            client.inGameHud.setOverlayMessage(
                    new LiteralText("§cCan't sell " + cachedName + ". Change the item."), false);
        }
    }

    /** Parses the item id only when the selection changed. */
    private boolean resolve(String key) {
        if (key.equals(cachedKey)) return cachedItem != Items.AIR;
        cachedKey = key;
        cachedItem = Items.AIR;
        Identifier id = Identifier.tryParse(key);
        if (id != null && Registry.ITEM.containsId(id)) {
            cachedItem = Registry.ITEM.get(id);
            cachedPath = id.getPath();
            cachedName = new ItemStack(cachedItem).getName().getString();
        }
        return cachedItem != Items.AIR;
    }

    private int countItem(MinecraftClient client) {
        int total = 0;
        for (ItemStack stack : client.player.getInventory().main) {
            if (stack.getItem() == cachedItem) total += stack.getCount();
        }
        return total;
    }
}
