package com.ggsun.autosell;

import com.ggsun.autosell.gui.AutoSellScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.ingame.GameMenuScreen;
import net.minecraft.client.gui.widget.AbstractButtonWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.LiteralText;

import java.util.List;

@Environment(EnvType.CLIENT)
public class AutoSellMod implements ClientModInitializer {

    public static AutoSellConfig config;
    public static AutoSellManager manager;

    @Override
    public void onInitializeClient() {
        config = AutoSellConfig.load();
        manager = new AutoSellManager();

        ClientTickEvents.END_CLIENT_TICK.register(client -> manager.onTick(client));

        // Make sure pending history reaches the disk when the game closes
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> config.saveIfDirty());

        // "AutoSell" button in the Pause menu, right below Disconnect
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof GameMenuScreen)) return;
            try {
                List<AbstractButtonWidget> buttons = Screens.getButtons(screen);

                int lowestY = 0;
                int x = scaledWidth / 2 - 102;
                int w = 204;
                for (AbstractButtonWidget b : buttons) {
                    if (b.y > lowestY) {
                        lowestY = b.y;
                        x = b.x;
                        w = b.getWidth();
                    }
                }

                buttons.add(new ButtonWidget(x, lowestY + 24, w, 20,
                        new LiteralText("AutoSell: " + (config.enabled ? "§aON" : "§cOFF")),
                        btn -> client.setScreen(new AutoSellScreen(screen))));
            } catch (Exception ignored) {
                // never break the pause menu
            }
        });
    }
}
