package com.ggsun.autosell;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

public class AutoSellConfig {

    private static final Gson GSON = new GsonBuilder().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("autosell.json");

    public static final int MAX_HISTORY = 10;

    // Typed exactly as the user wrote it, e.g. "/sell hand" or "/sell {item}"
    public String sellCommand = "";
    // Full item id, e.g. "minecraft:diamond"
    public String selectedItem = "";
    public boolean enabled = false;
    // Ticks between attempts (20 = 1 second). One item per attempt.
    public int sellIntervalTicks = 20;
    public boolean hideServerMessages = true;
    // Newest first, max 10
    public List<SellRecord> history = new ArrayList<>();

    private transient boolean dirty = false;

    public static AutoSellConfig load() {
        AutoSellConfig cfg = null;
        try {
            if (Files.exists(CONFIG_PATH)) {
                String json = new String(Files.readAllBytes(CONFIG_PATH), StandardCharsets.UTF_8);
                cfg = GSON.fromJson(json, AutoSellConfig.class);
            }
        } catch (Exception e) {
            // corrupted file -> start fresh instead of crashing
        }
        if (cfg == null) cfg = new AutoSellConfig();
        cfg.sanitize();
        return cfg;
    }

    private void sanitize() {
        if (sellCommand == null) sellCommand = "";
        if (selectedItem == null) selectedItem = "";
        if (sellIntervalTicks < 10) sellIntervalTicks = 10;
        if (sellIntervalTicks > 20 * 3600) sellIntervalTicks = 20 * 3600;
        if (history == null) history = new ArrayList<>();
        history.removeIf(r -> r == null || r.item == null);
        while (history.size() > MAX_HISTORY) history.remove(history.size() - 1);
    }

    /** Cheap: just records the entry in memory. Disk write happens later. */
    public void addHistory(String itemName, int qty) {
        history.add(0, new SellRecord(itemName, qty, System.currentTimeMillis()));
        while (history.size() > MAX_HISTORY) history.remove(history.size() - 1);
        dirty = true;
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    /** Writes to a temp file first, so a crash mid-write can't corrupt the config. */
    public void save() {
        dirty = false;
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Path tmp = CONFIG_PATH.resolveSibling("autosell.json.tmp");
            Files.write(tmp, GSON.toJson(this).getBytes(StandardCharsets.UTF_8));
            try {
                Files.move(tmp, CONFIG_PATH, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, CONFIG_PATH, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException | RuntimeException e) {
            // ignore: never crash the game over a config write
        }
    }
}
